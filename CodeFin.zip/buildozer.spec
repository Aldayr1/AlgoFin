[app]

# Configurações Básicas
title = AlgoFin Teste
package.name = algofinteste
package.domain = br.com.aldair
source.dir = .
source.include_exts = py,png,jpg,kv,json
version = 0.1

# TRAVA DUPLA DE VERSÃO: Garante o Python 3.11 no host e no aplicativo
requirements = python3==3.11,hostpython3==3.11,kivy==2.3.0,kivymd==1.1.1

# Configurações do Android
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

# MÁQUINA DO TEMPO: Trava o motor para não buscar ferramentas experimentais do Python 3.14
p4a.branch = v2024.01.21

[buildozer]
# Configurações de Log e Servidor
log_level = 2
warn_on_root = 1