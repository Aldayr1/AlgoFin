[app]
title = AlgoFin Educacional
package.name = algofin
package.domain = br.com.aldair
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json
version = 0.1

# O FIX DO COPILOT: Trava o pacote interno do Android no Python 3.11
requirements = python3==3.11,hostpython3==3.11,kivy==2.3.0,kivymd==1.1.1,requests,urllib3,charset-normalizer,idna,certifi

orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1

p4a.branch = v2024.01.21