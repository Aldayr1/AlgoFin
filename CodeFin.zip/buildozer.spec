[app]
title = AlgoFin Educacional
package.name = algofin
package.domain = br.com.aldair
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json
version = 0.1

# Deixamos apenas python3. O motor travado em 2024 sabe exatamente qual versão usar!
requirements = python3,kivy==2.3.0,kivymd==1.1.1,requests,urllib3,charset-normalizer,idna,certifi

orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

# A MÁQUINA DO TEMPO AGORA ESTÁ NO LUGAR CERTO
p4a.branch = v2024.01.21

[buildozer]
log_level = 2
warn_on_root = 1