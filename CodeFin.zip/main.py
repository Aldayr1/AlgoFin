import os
import json
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.utils import platform
from kivy.properties import StringProperty, NumericProperty
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen

# Configuração de Janela para Computador (Testes no VS Code)
if platform != 'android':
    Window.size = (360, 640)

# Telas Falsas (Mock Screens) para o teste
class InicialScreen(MDScreen):
    pass

class PerfilScreen(MDScreen):
    pass

class SobreScreen(MDScreen):
    pass

ROOT_KV = '''
MDNavigationLayout:
    MDScreenManager:
        id: screen_manager

        InicialScreen:
            name: 'inicial'
            MDBoxLayout:
                orientation: 'vertical'
                MDTopAppBar:
                    title: "AlgoFin - Início"
                    md_bg_color: app.theme_cls.primary_color
                    left_action_items: [["menu", lambda x: nav_drawer.set_state("open")]]
                MDLabel:
                    text: "Tela Inicial Ativa! Teste de Compilação OK."
                    halign: "center"
                Widget:

        PerfilScreen:
            name: 'perfil'
            MDBoxLayout:
                orientation: 'vertical'
                MDTopAppBar:
                    title: "AlgoFin - Perfil"
                    md_bg_color: app.theme_cls.primary_color
                    left_action_items: [["menu", lambda x: nav_drawer.set_state("open")]]
                MDLabel:
                    text: f"Usuário: {app.user_name}\\nMoedas: {app.moedas}"
                    halign: "center"
                Widget:

        SobreScreen:
            name: 'sobre'
            MDBoxLayout:
                orientation: 'vertical'
                MDTopAppBar:
                    title: "AlgoFin - Sobre"
                    md_bg_color: app.theme_cls.primary_color
                    left_action_items: [["menu", lambda x: nav_drawer.set_state("open")]]
                MDLabel:
                    text: "Aplicativo em fase de testes."
                    halign: "center"
                Widget:

    MDNavigationDrawer:
        id: nav_drawer
        MDNavigationDrawerMenu:
            MDNavigationDrawerHeader:
                title: "AlgoFin"
                title_color: app.theme_cls.primary_color
                text: "Educação Financeira e Computação"
                spacing: "8dp"
                padding: "12dp", 0, 0, "36dp"
                
            MDNavigationDrawerItem:
                icon: "home"
                text: "Início"
                on_release: screen_manager.current = 'inicial'; nav_drawer.set_state("close")
            MDNavigationDrawerItem:
                icon: "account-circle"
                text: "Perfil"
                on_release: screen_manager.current = 'perfil'; nav_drawer.set_state("close")
            MDNavigationDrawerItem:
                icon: "information"
                text: "Sobre"
                on_release: screen_manager.current = 'sobre'; nav_drawer.set_state("close")
'''

class AlgoFinApp(MDApp):
    user_name = StringProperty("Utilizador")
    escola = StringProperty("Escola")
    turma = StringProperty("Turma")
    nivel_modulo1 = NumericProperty(1)
    nivel_modulo2 = NumericProperty(1)
    nivel_modulo3 = NumericProperty(1)
    moedas = NumericProperty(0)

    def build(self):
        self.theme_cls.primary_palette = "Indigo"
        self.load_data()
        return Builder.load_string(ROOT_KV)

    def pegar_caminho_json(self):
        return os.path.join(self.user_data_dir, "user_data.json")

    def load_data(self):
        caminho = self.pegar_caminho_json()
        if os.path.exists(caminho):
            try:
                with open(caminho, "r", encoding='utf-8') as f:
                    dados = json.load(f)
                    self.user_name = dados.get("nome", "Utilizador")
                    self.moedas = dados.get("moedas", 0) 
                    self.escola = dados.get("escola", "Escola")
                    self.turma = dados.get("turma", "Turma")
                    self.nivel_modulo1 = dados.get("nivel_modulo1", 1) 
                    self.nivel_modulo2 = dados.get("nivel_modulo2", 1)
                    self.nivel_modulo3 = dados.get("nivel_modulo3", 1)
            except Exception:
                pass

    def save_data(self):
        dados = {
            "nome": self.user_name,
            "escola": self.escola,
            "moedas": self.moedas,
            "turma": self.turma,
            "nivel_modulo1": self.nivel_modulo1,
            "nivel_modulo2": self.nivel_modulo2,
            "nivel_modulo3": self.nivel_modulo3
        }
        caminho = self.pegar_caminho_json()
        try:
            with open(caminho, "w", encoding='utf-8') as f:
                json.dump(dados, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Erro ao salvar dados: {e}")

if __name__ == '__main__':
    AlgoFinApp().run()